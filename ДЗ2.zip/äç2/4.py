n = int(input())
m = 1
p = 0
for i in range(n):
	p += m
	m /= -2
print(p)